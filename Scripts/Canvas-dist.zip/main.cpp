#include "include/EntryPoint.h"
#include "include/Canvas.h"

void Setup()
{
}

void Draw()
{
}
